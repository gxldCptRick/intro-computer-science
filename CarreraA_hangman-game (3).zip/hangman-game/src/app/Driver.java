package app;

import controllers.HangManGame;

public class Driver {

	public static void main(String[] args) {
		
		HangManGame.start();
		
	}

}
