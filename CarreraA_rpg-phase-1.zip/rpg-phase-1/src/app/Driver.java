package app;

import controllers.GameMaster;

public class Driver {

	public static void main(String[] args) {
		(new GameMaster()).start();
	}
	
}
