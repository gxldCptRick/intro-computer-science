package enums;

public enum Bonus {

	DAMAGE,
	STRIKE,
	DODGE,
	SPELL_STRENGTH
	
}
