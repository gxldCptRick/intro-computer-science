package enums;

public enum Attribute {

	STRENGTH,
	DEXTERITY,
	INTELLIGENCE
	
}
