package enums;

public enum DieFace {
	BRAIN,
	SHOT,
	RUN
}
