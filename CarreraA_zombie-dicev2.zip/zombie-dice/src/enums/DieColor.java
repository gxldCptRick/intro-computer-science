package enums;

public enum DieColor {
	GREEN,
	YELLOW,
	RED
}
