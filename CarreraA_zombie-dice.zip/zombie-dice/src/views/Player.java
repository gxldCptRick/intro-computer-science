package views;

public class Player {
	private String name;
	private int brainCount;
	private boolean isTurn;

	public void addBrains(int amountOfBrains) {

		this.brainCount += amountOfBrains;

	}

	public void setTurn(boolean turnState) {
		this.isTurn = turnState;
	}

	public boolean getTurn() {

		return this.isTurn;

	}

	public String getName() {

		return this.name;

	}

	public int getBrainCount() {

		return this.brainCount;

	}


	public Player(String name) {
		this.name = name;
		this.isTurn = false;
		this.brainCount = 0;
	}

}
