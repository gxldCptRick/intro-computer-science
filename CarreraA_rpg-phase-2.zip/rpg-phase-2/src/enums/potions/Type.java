package enums.potions;

/** <h1> Type enum</h1>
 * <p> this enum is all the possible types of potions in the RPG.</p>
 * @author Andres Hermilo Carrera
 * @since November 24, 2017
 * @version v1.0
 */
public enum Type {
HEALTH,
MANA
}
