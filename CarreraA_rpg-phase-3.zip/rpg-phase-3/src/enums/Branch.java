package enums;

public enum Branch {
	NEXT_PHASE,
	FINAL_PHASE,
	SIDE_QUEST
}
