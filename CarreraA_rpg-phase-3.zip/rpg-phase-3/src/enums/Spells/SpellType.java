package enums.Spells;

public enum SpellType {
	DAMAGE,
	HEAL
}
