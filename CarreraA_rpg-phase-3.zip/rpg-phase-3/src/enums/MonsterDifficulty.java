package enums;

public enum MonsterDifficulty {
	EASY,
	MEDIUM,
	HARD,
	EXPERT,
	KAMI
}
