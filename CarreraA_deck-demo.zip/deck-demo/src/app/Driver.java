package app;

import controllers.Game;

public class Driver {

	public static void main(String[] args) {
		(new Game()).run();
	}

}
