package enums;

public enum Suit {
	DIAMONDS,
	HEARTS,
	CLUBS,
	SPADES
}
