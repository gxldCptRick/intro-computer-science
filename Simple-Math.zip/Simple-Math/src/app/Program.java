package app;

public class Program {

	public static void main(String[] args) {
		
		int x = 4, y = 20 , total;
		
		total =  x + y;
		
		System.out.println(x + " + " + y + " = " + total);
		
		total = x - y;
		
		System.out.println(x + " - " + y + " = " + total);
		
		total = x * y;
		
		System.out.println(x + " * "+ y + " = " + total);
		
		total = x / y;
		
		System.out.println(x + " / " + y + " = " + total);
		
		total = x % y;
		
		System.out.println(x + " % "+ y + " = " + total);

	}

}
