package app;

/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
/**
 * @author Andres
 *
 */
public class Fraction {

	
	private int numerator = 0, denominator = 1, wholeNum = 0;
	private double decimalValue = 0.0;

	/**
	 * @return numerator
	 */
	public int getNumerator() {
		return numerator;
	}

	/**
	 * @param numerator sets the numerator of the fraction
	 */
	public void setNumerator(int numerator) {
		this.numerator = numerator;
	}

	/**
	 * @return the denominator of the fraction  
	 */
	public int getDenominator() {
		return denominator;
	}

	/**
	 * @param denominator set the denominator of the fraction
	 */
	public void setDenominator(int denominator) {
		this.denominator = denominator;
	}

	/**
	 * @return the decimal value of the fraction
	 */
	public double getDecimalValue() {
		return decimalValue;
	}

	/**
	 * @param decimalValue sets the decimal value of the fraction
	 */
	public void setDecimalValue(double decimalValue) {
		this.decimalValue = decimalValue;
	}

	/**
	 * @param wholeNum sets the whole value of the fraction
	 */
	public void setWholeNum(int wholeNum) {
		this.wholeNum = wholeNum;
	}

	/**
	 * @param temp temporary fraction that is compared to current fraction
	 * @return the expression of if all the values of the fraction are equivalent
	 */
	public boolean equals(Fraction temp) {
		return ((this.numerator == temp.numerator) && (this.denominator == temp.denominator)
				&& (this.wholeNum == temp.wholeNum));
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * this is formating a fraction into a string representation of it.
	 */
	public String toString() {
		if (this.denominator == 1) {
			return (this.wholeNum + "");
		} else if (this.wholeNum != 0) {
			return (this.wholeNum + " " + this.numerator + "/" + this.denominator);
		} else {
			return (this.numerator + "/" + this.denominator);
		}
	}

	/**
	 * simplifies the fraction and sets it as the current fraction.
	 */
	public void simplify() {

		int gcf = 0;

		if (this.numerator > this.denominator || (this.numerator < this.denominator && this.numerator < 0)) {
			
			this.wholeNum += this.numerator / this.denominator;
			
			if(this.numerator < 0) {
			
				this.numerator *= -1;
				
			}
			
			this.numerator %= this.denominator;
			
		
		} else if (this.numerator == this.denominator) {
			
			this.wholeNum += 1;
			
			this.denominator = 1;
			
			this.numerator = 1;
		
		}
		
		gcf = greatestCommonFactor(this.numerator, this.denominator);
		
		this.numerator /= gcf;
		
		this.denominator /= gcf;

	}

	/**
	 * @param num the numerator of the fractions.
	 * @param dem the denominator of the fraction. 
	 * @param whole the whole number of the fraction. 
	 * @throws ArithmeticException It is thrown if dem is set to 0.
	 */
	public Fraction(int num, int dem, int whole) throws ArithmeticException {

		this.numerator = num;

		if (dem == 0) {
			throw new ArithmeticException();
		}

		this.denominator = dem;

		this.wholeNum = whole;

		this.decimalValue = ((double) num) / dem + wholeNum;

	}

	/**
	 * @param num numerator of the fraction.
	 * @param dem denominator of the fraction.
	 */
	public Fraction(int num, int dem) {
		
		this.numerator = num;

		if (dem == 0) {
			throw new ArithmeticException();
		}

		this.denominator = dem;

		this.decimalValue = ((double) num) / dem;

	}

	/**
	 * is the most basic fraction that can be created. 
	 */
	public Fraction() {
	}

	/**
	 * @param frac1 the fraction that you are adding with this fraction.
 	 * @return the sum of both fractions.
	 */
	public Fraction add(Fraction frac1) {
		int wholeNum = this.wholeNum + frac1.wholeNum, numNum = 0, demNum = this.denominator;

		if (this.denominator == frac1.denominator) {
			numNum = this.numerator + frac1.numerator;

		} else {
			numNum = this.numerator * frac1.denominator + this.denominator * frac1.numerator;
			demNum = this.denominator * frac1.denominator;
		}
		return new Fraction(numNum, demNum, wholeNum);

	}

	/**
	 * @param frac1 fraction that is being subtracted from current fraction
	 * @return the difference between frac1 and this fraction
	 */
	public Fraction subtract(Fraction frac1) {

		int numNum = 0, demNum = 1;

		if (this.denominator == frac1.denominator) {

			demNum = this.denominator;
			
			numNum = this.numerator + this.wholeNum * demNum;
			
			numNum -= frac1.numerator + frac1.wholeNum * demNum;
	

		} else {
			
			numNum = (this.numerator + this.wholeNum * this.denominator) * frac1.denominator;
			
			numNum -= (frac1.numerator + frac1.wholeNum * frac1.denominator) * this.denominator;
			
			demNum = this.denominator * frac1.denominator;
		}

		return new Fraction(numNum, demNum);
	}

	/**
	 * @param frac1 fraction that is multiplied to this fraction.
	 * @return the product of the frac1 and this fraction.
	 */
	public Fraction multiply(Fraction frac1) {

		int numNum = 0, demNum = 1;
		
		numNum = this.numerator + this.wholeNum * this.denominator;
		
		numNum *= frac1.numerator + frac1.wholeNum * frac1.denominator;
		
		demNum *= this.denominator * frac1.denominator;
		
		return new Fraction(numNum, demNum);

	}

	/**
	 * @param frac1 the divisor between this fraction and frac1
	 * @return the quotient of this division
	 */
	public Fraction divide(Fraction frac1) {

		int numNum = 0, demNum = 1;
		
		numNum = frac1.denominator;
		
		demNum = frac1.numerator + frac1.denominator * frac1.wholeNum;
		
		Fraction flippedFrac1 = new Fraction(numNum, demNum);

		return flippedFrac1.multiply(this);

	}


	private int greatestCommonFactor(int num, int dem) {

		if (dem == 0) {
			return num;
		} else {
			return greatestCommonFactor(dem, num % dem);
		}
	}
}
